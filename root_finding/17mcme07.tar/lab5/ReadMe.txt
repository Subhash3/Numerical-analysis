----Test Case - 1------

Enter the value of x and y as inputs and then the value of xi.
If you are done by entering the polynomial terms then type any lower case letter to terminate the input process.

Enter the value of x: 5
Enter the value of f(x): 12

Enter the value of x: 6
Enter the value of f(x): 13

Enter the value of x: 9
Enter the value of f(x): 14

Enter the value of x: 11
Enter the value of f(x): 16

Enter the value of x: a
Enter the value of at whose function value is to be found: 10

Function value at 10.000000 is: 14.666666

-------Test case - 2 ---------
Enter the value of x and y as inputs and then the value of xi.
If you are done by entering the polynomial terms then type any lower case letter to terminate the input process.

Enter the value of x: 1
Enter the value of f(x): 1

Enter the value of x: 2
Enter the value of f(x): 8

Enter the value of x: 3
Enter the value of f(x): 27

Enter the value of x: 4
Enter the value of f(x): 64

Enter the value of x: k
Enter the value of at whose function value is to be found: 0.25

Function value at 2.500000 is: 15.625000
